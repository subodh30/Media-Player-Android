package com.example.subodh_sudeep.mediaplayer;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.NotificationCompat;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class songlay extends AppCompatActivity implements View.OnClickListener {

    static MediaPlayer mp ;
    ImageButton ff,fb,nxt,prv,close;
    ImageView pp,loop;
    TextView name,time,curtime;
    SeekBar s;
    int position;
    int fileSize;
    Uri u;
    ArrayList<File> songList;
Handler h = new Handler();

    NotificationCompat.Builder noti;
    private static final int id=3455;
    NotificationManager nm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songlay);
        name = (TextView) findViewById(R.id.sname);
        loop=(ImageView)findViewById(R.id.loop);
        time = (TextView) findViewById(R.id.time);
        curtime = (TextView) findViewById(R.id.curtime);
        pp = (ImageView) findViewById(R.id.pp);
        ff= ( ImageButton)findViewById(R.id.ff);
        fb = (ImageButton) findViewById(R.id.fb);
        prv= (ImageButton)findViewById(R.id.previous);
        nxt = (ImageButton) findViewById(R.id.next);
        close = (ImageButton) findViewById(R.id.close);
        s = (SeekBar)findViewById(R.id.seekBar);
        pp.setOnClickListener(this);
        ff.setOnClickListener(this);
        fb.setOnClickListener(this);
        nxt.setOnClickListener(this);
        prv.setOnClickListener(this);
        close.setOnClickListener(this);
        if(mp!=null)
        {
            mp.stop();
            mp.release();
        }


        Intent i = getIntent();
        Bundle b = i.getExtras();
        songList = (ArrayList) b.getParcelableArrayList("files");
        position = b.getInt("position",0);
        name.setText(songList.get(position).getName().toString());
        fileSize=songList.size();
        u = Uri.parse(songList.get(position).toString());

        mp= MediaPlayer.create(getApplicationContext(),u);

        s.setMax(mp.getDuration());

        double mili = mp.getDuration();
        int sec =(int) mili/1000;
        int min= sec/60;
        int ss= sec%60;
        String mins = String.format("%2s",String.valueOf(min)).replace(' ','0');
        String sss = String.format("%2s",String.valueOf(ss)).replace(' ','0');
        time.setText(mins+":"+sss);
        mp.start();
        update();
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (b) {
                    mp.seekTo(i);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                mp.seekTo(s.getProgress());
            }
        });
        noti = new NotificationCompat.Builder(this);
        noti.setAutoCancel(false);
        noti.setSmallIcon(R.drawable.music);
        noti.setContentTitle(songList.get(position).getName().toString());

        Intent intent = new Intent(songlay.this,songlay.class).putExtra("position",position).putExtra("files",songList);
        intent.setFlags( Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
        ActivityManager.RunningTaskInfo task = tasks.get(0); // Should be my task
        ComponentName rootActivity = task.baseActivity;

        intent.setComponent(rootActivity);
        intent.setAction(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);

        noti.setContentIntent(pendingIntent);
         nm = ( NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.cancelAll();
        nm.notify(id,noti.build());
    }


   Runnable run = new Runnable() {
       @Override
       public void run() {
           update();
       }
   };

   void update(){
       double mili = mp.getCurrentPosition();
       int sec =(int) mili/1000;
       int min= sec/60;
       int ss= sec%60;
       String mins = String.format("%2s",String.valueOf(min)).replace(' ','0');
       String sss = String.format("%2s",String.valueOf(ss)).replace(' ','0');
       curtime.setText(mins+":"+sss);
       s.setProgress(mp.getCurrentPosition());

      // Toast.makeText(getApplicationContext(),"lol",Toast.LENGTH_SHORT).show();
       if(mp.getCurrentPosition()>=(mp.getDuration()-5)){
          // Toast.makeText(getApplicationContext(),"lollll",Toast.LENGTH_SHORT).show();
           if(!mp.isLooping()) {
               finish();
               startActivity(new Intent(songlay.this, songlay.class).putExtra("position", (position + 1)).putExtra("files", songList));
           }
       }
       h.postDelayed(run,100);
   }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch(id) {
            case R.id.pp :
                if(mp.isPlaying()){
                    mp.pause();
                    pp.setImageResource(R.drawable.play);
                }
                else{
                    mp.start();
                    pp.setImageResource(R.drawable.pause);
                }
                break;
            case R.id.ff:
                mp.seekTo(mp.getCurrentPosition()+5000);
                break;
            case R.id.fb:
                mp.seekTo(mp.getCurrentPosition()-5000);
                break;
            case R.id.next :
                mp.stop();
                mp.release();
                position++;
                position %= fileSize;
                u = Uri.parse(songList.get(position).toString());
                name.setText(songList.get(position).getName().toString());
                mp = MediaPlayer.create(getApplicationContext(), u);
                s.setProgress(0);
                double mili = mp.getDuration();
                int sec =(int) mili/1000;
                int min=(int) sec/60;
                int ss= sec%60;
                String mins = String.format("%2s",min).replace(' ','0');
                String sss = String.format("%2s",ss).replace(' ','0');
                time.setText(mins+":"+sss);
                s.setMax(mp.getDuration());
                nm.cancelAll();
                noti.setContentTitle(songList.get(position).getName().toString());
                nm.notify(id,noti.build());
                mp.start();
               update();
                break;
            case R.id.previous :
                mp.stop();
                mp.release();
                position--;
               if(position<0) position=fileSize-1;
                u = Uri.parse(songList.get(position).toString());
                name.setText(songList.get(position).getName().toString());
                mp = MediaPlayer.create(getApplicationContext(), u);
                s.setProgress(0);
                double mili1 = mp.getDuration();
                int sec1 =(int) mili1/1000;
                int min1=(int) sec1/60;
                int ss1= sec1%60;
                String mins1 = String.format("%2s",min1).replace(' ','0');
                String sss1 = String.format("%2s",ss1).replace(' ','0');
                time.setText(mins1+":"+sss1);
                s.setMax(mp.getDuration());
                nm.cancelAll();
                noti.setContentTitle(songList.get(position).getName().toString());
                nm.notify(id,noti.build());
                mp.start();
                update();
                break;
            case R.id.close:
                if(!mp.isLooping())
                {
                    loop.setVisibility(View.VISIBLE);
                    mp.setLooping(true);
                }
                else{
                    loop.setVisibility(View.INVISIBLE);
                    mp.setLooping(false);
                }
              break;
        }
    }
}
