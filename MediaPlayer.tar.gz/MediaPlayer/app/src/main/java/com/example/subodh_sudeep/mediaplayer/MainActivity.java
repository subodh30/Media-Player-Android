package com.example.subodh_sudeep.mediaplayer;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.NotificationCompat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    String[] names;
    File[] f;
    ArrayList <File> mysongs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView) findViewById(R.id.list);

           mysongs = find(Environment.getExternalStorageDirectory());
         names = new String[mysongs.size()];
        for (int i=0;i<mysongs.size();i++)
        {
            names[i] = mysongs.get(i).getName().toString().replace(".mp3","").replace(".wav","");
        }

        ArrayAdapter<String> adp = new ArrayAdapter<String>(getApplicationContext(),R.layout.song_lay,R.id.textView11,names);
        lv.setAdapter(adp);


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

          @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                startActivity(new Intent(MainActivity.this,songlay.class).putExtra("position",i).putExtra("files",mysongs));
            }
        });
    }




    public ArrayList<File>  find(File root)
    {
        ArrayList<File> af = new ArrayList<>();
         f = root.listFiles();
        for(File sf: f){
            if(sf.isDirectory() && !sf.isHidden())
            {
                af.addAll(find(sf));
            }
            else{
                if(sf.getName().endsWith(".mp3") || sf.getName().endsWith(".wav"))
                {
                    af.add(sf);
                }
            }
        }
        return af;
    }

}
